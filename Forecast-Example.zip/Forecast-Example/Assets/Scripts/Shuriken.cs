﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shuriken : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    private ForeCastManager fm;

    public bool IsDeflected;


    private Vector3 recordedvel;
    private float recordedmag;
    private Vector3 recordedposition;

    private bool IsDeflectetemp;

    public LayerMask layerMask;

    private Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        fm = FindObjectOfType<ForeCastManager>();
        rb = GetComponent<Rigidbody>();
        rb.velocity = transform.forward * speed;
        anim = GetComponentInChildren<Animator>();

    }

    // Update is called once per frame
    private void OnCollisionEnter(Collision col)
    {
        if (!IsDeflected && !fm.IsForecast)
        {
            
                if (col.collider.GetComponent<Player>())
                {
                if (!col.collider.GetComponent<Player>().isDashInvincible)
                {
                    col.collider.GetComponent<Player>().Die();
                    col.collider.GetComponent<Rigidbody>().velocity = transform.forward * 10f;
                    transform.parent = col.transform;
                    rb.velocity = Vector3.zero;
                    rb.isKinematic = true;
                    IsDeflected = true;
                    anim.speed = 0f;
                }
                }
                else
                {


                    rb.velocity = Vector3.zero;
                    rb.isKinematic = true;
                    IsDeflected = true;
                    anim.speed = 0f;
                    Invoke("Gone", 3f);
                }
            
        }
    }
    void Update()
    {

        if (!IsDeflected)
        {
            if (fm.ForeCastStart)
            {
                recordedmag = rb.velocity.magnitude;
                recordedvel = rb.velocity.normalized;
                recordedposition = transform.position;
                IsDeflectetemp = IsDeflected;
            }
            if (fm.ForeCastEnd)
            {
                IsDeflected = IsDeflectetemp;

                transform.position = recordedposition;
                rb.velocity = recordedvel * recordedmag;
                if (recordedposition == Vector3.zero)
                {
                    Destroy(gameObject);
                }
            }
            if (IsDeflected)
            {
                rb.useGravity = true;
            }
        }
      
    }
    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(transform.position, transform.position + transform.forward * 1f);
    }
    void Gone()
    {
        Destroy(gameObject);

    }
}
