﻿using System;
using System.Collections;
using UnityEngine;









namespace UnityStandardAssets.Characters.FirstPerson
{
    [RequireComponent(typeof (Rigidbody))]
    [RequireComponent(typeof (CapsuleCollider))]
    public class RigidbodyFirstPersonController : MonoBehaviour
    {


        [Serializable]
        public class MovementSettings
        {

            public float ForwardSpeed = 8.0f;   // Speed when walking forward
            public float BackwardSpeed = 4.0f;  // Speed when walking backwards
            public float StrafeSpeed = 4.0f;    // Speed when walking sideways
            public float RunMultiplier = 2.0f;   // Speed when sprinting

        }
      

	    public Vector3 relativeMovement;
        public Vector3 relativeMovementUpdate;
        public Vector3 relativeTransform;

        public Transform cam;
        public MovementSettings movementSettings = new MovementSettings();
        public MouseLook mouseLook = new MouseLook();
    

		public float RBFDspeed;
        public float Aftergroundedtimer = 0.2f;
        private float aftergrounded;

  

        public DetectObstruction DetectGround;



        private Rigidbody m_RigidBody;
        private CapsuleCollider m_Capsule;
        private float m_YRotation;


        public bool  IsGrounded;

		public bool canrotate = true;
		public bool rotatecamonly;
		public bool camgoback;
        public bool CanMove = true;
        
        
        private Vector3 lastpos;
        public Vector3 Velocity
        {
            get { return m_RigidBody.velocity; }
        }

      

        private void Start()
        {
            InvokeRepeating("LastPos", 0f, 0.1f);

            m_RigidBody = GetComponent<Rigidbody>();
            m_Capsule = GetComponent<CapsuleCollider>();
            mouseLook.Init (transform, cam.transform);
            InvokeRepeating("Repeat", 0, .1f);

        
        }
        void Repeat()
        {
            relativeMovement = transform.InverseTransformDirection(m_RigidBody.velocity);

        }

        void LastPos()
        {
            lastpos = transform.position;
            Invoke("UpdatePos", 0.05f);
        }
        void UpdatePos()
        {
            relativeTransform = transform.position - lastpos;

        }
        private void LateUpdate()
        {
			if (canrotate ) {
				RotateView ();
			} 
			if(!canrotate)
			
			{
				RotateOveride ();
			}
			if (rotatecamonly) {
				RotateOverideCamOnly ();
			} 



		
        }

		private void RotateView()
		{

		
			transform.rotation = Quaternion.Euler (0, transform.rotation.eulerAngles.y, 0);


			cam.transform.localRotation = Quaternion.Euler (cam.transform.localRotation.x, 0, 0);



			//avoids the mouse looking if the game is effectively paused
			if (Mathf.Abs(Time.timeScale) < float.Epsilon) return;

			// get the rotation before it's changed
			float oldYRotation = transform.eulerAngles.y;

			mouseLook.LookRotation (transform, cam.transform);

			if (IsGrounded)
			{
				// Rotate the rigidbody velocity to match the new direction that the character is looking
				Quaternion velRotation = Quaternion.AngleAxis(transform.eulerAngles.y - oldYRotation, Vector3.up);
				m_RigidBody.velocity = velRotation*m_RigidBody.velocity;
			}
		}

		private void RotateOveride()
		{
			if (!rotatecamonly) {
				mouseLook.LookRotationOverride (transform, cam.transform);
			}
	

		}

		private void RotateOverideCamOnly()
		{
			mouseLook.LookRotationOverideCam (transform, cam.transform);

		}

		public void CamGoBack(float speed)
		{
			mouseLook.CamGoBack(transform, cam.transform ,speed);

		}

        
	
        private void Update()
        {

            relativeMovementUpdate = transform.InverseTransformDirection(m_RigidBody.velocity);

            GroundCheck();
           

            if (!IsGrounded && CanMove)
            {
                if (Input.GetAxis("Vertical") > 0)
                {
                    m_RigidBody.AddRelativeForce(0, 0, Time.deltaTime * RBFDspeed * Mathf.Abs(Input.GetAxis("Vertical")));
                }
                if (Input.GetAxis("Vertical") < 0)
                {
                    m_RigidBody.AddRelativeForce(0, 0, Time.deltaTime * -RBFDspeed * Mathf.Abs(Input.GetAxis("Vertical")));
                }
                if (Input.GetAxis("Horizontal") > 0.7f)
                {
                    m_RigidBody.AddRelativeForce(Time.deltaTime * RBFDspeed * Mathf.Abs(Input.GetAxis("Horizontal")), 0, 0);
                }
                if (Input.GetAxis("Horizontal") < -0.7)
                {
                    m_RigidBody.AddRelativeForce(Time.deltaTime * -RBFDspeed * Mathf.Abs(Input.GetAxis("Horizontal")), 0, 0);
                }
            }

            Vector2 input = GetInput();

           

            float h = input.x;
            float v = input.y;
            Vector3 inputVector = new Vector3(h, 0, v);
            inputVector = Vector3.ClampMagnitude(inputVector, 1);
            if(CanMove && IsGrounded)
            {
               
               
                    if (Input.GetAxisRaw("Vertical") > 0.3f)
                    {
                        m_RigidBody.AddRelativeForce(0, 0, Time.deltaTime * movementSettings.ForwardSpeed * 0.5f * Mathf.Abs(inputVector.z));
                    }
                    if (Input.GetAxisRaw("Vertical") < -0.3f)
                    {
                        m_RigidBody.AddRelativeForce(0, 0, Time.deltaTime  * -movementSettings.BackwardSpeed  * 0.5f * Mathf.Abs(inputVector.z));
                    }
                    if (Input.GetAxisRaw("Horizontal") > 0.5f)
                    {
                        m_RigidBody.AddRelativeForce(Time.deltaTime * movementSettings.StrafeSpeed  * 0.5f * Mathf.Abs(inputVector.x), 0, 0);
                    }
                    if (Input.GetAxisRaw("Horizontal") < -0.5f)
                    {
                        m_RigidBody.AddRelativeForce(Time.deltaTime * -movementSettings.StrafeSpeed  * 0.5f * Mathf.Abs(inputVector.x), 0, 0);
                    }
                
            }
            if(IsGrounded)
            {
                aftergrounded = Aftergroundedtimer;
            }
            else
            {
                aftergrounded -= Time.deltaTime;
            }

        }
        private void GroundCheck()
        {

            if (DetectGround.Obstruction)
            {
                IsGrounded = true;
            }
            else
            {
                IsGrounded = false;
            }
        }


        private Vector2 GetInput()
        {
			
            
            Vector2 input = new Vector2

                {
				x =Input.GetAxisRaw("Horizontal"),
				y = Input.GetAxisRaw("Vertical")
                };


            return input;
        }



			
    }
	}

