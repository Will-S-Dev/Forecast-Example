﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackCollider : MonoBehaviour
{
    public string ObjectTagName = "";
    public bool Obstruction;
    public float force;
    public float torque;
    private Player player;

    private void Start()
    {
        player = GetComponentInParent<Player>();
    }
    void OnTriggerEnter(Collider col)
    {
        if (ObjectTagName != "")
        {
            if (col != null && !col.isTrigger && col.CompareTag(ObjectTagName))
            {
                if (!col.GetComponent<EnemyAI>().IsDead)
                {
                    player.EnemyHit();

                    col.GetComponent<EnemyAI>().Die();
                    col.GetComponent<Rigidbody>().velocity = transform.forward * force;
                    col.GetComponent<Rigidbody>().maxAngularVelocity = 1000000f;
                    col.GetComponent<Rigidbody>().AddTorque(Random.Range(-torque, torque), 0, Random.Range(-torque, torque));
                }

            }
        }
     
       

        }
        

    }

