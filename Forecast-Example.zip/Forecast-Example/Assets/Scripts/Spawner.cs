﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Spawner : MonoBehaviour
{
    public GameObject enemy;
    public GameObject enemyred;

    public float currentWave;
    public float currentenemies;

    public Text wavetext;
    public Animator waveanim;



    public Transform spawn1;
   



    // Start is called before the first frame update
    void Update()
    {
        if(currentenemies <=0f)
        {
            startWave();
        }
    }

    // Update is called once per frame
    void startWave()
    {
        
        currentWave++;
        wavetext.text = "Wave "+ currentWave.ToString();
        waveanim.Play("WaveStart",0,0.01f);

      if(currentWave == 1f)
        {
          GameObject enemy_ =  Instantiate(enemy);
          
            enemy_.transform.position = new Vector3(Random.Range(-22,22),8,Random.Range(-14,14));

            currentenemies = 1f;
        }
        if (currentWave == 2f)
        {
            GameObject enemy_ = Instantiate(enemy);
            enemy_.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemy);
            enemy_2.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            currentenemies = 2f;

        }
        if (currentWave == 3f)
        {
            GameObject enemy_ = Instantiate(enemy);
            enemy_.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemy);
            enemy_2.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemy);
            enemy_3.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            currentenemies = 3f;

        }
        if (currentWave == 4f)
        {
            GameObject enemy_ = Instantiate(enemy);
            enemy_.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemy);
            enemy_2.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemy);
            enemy_3.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_4 = Instantiate(enemy);
            enemy_4.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            currentenemies = 4f;

        }
        if (currentWave == 5f)
        {
            currentenemies = 5f;

            GameObject enemy_ = Instantiate(enemy);
            enemy_.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemy);
            enemy_2.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemy);
            enemy_3.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_4 = Instantiate(enemy);
            enemy_4.transform.position =  new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_5 = Instantiate(enemy);
            enemy_5.transform.position= new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
        }
        if (currentWave == 6f)
        {
            currentenemies = 5f;

            GameObject enemy_ = Instantiate(enemyred);
            enemy_.transform.position  = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemy);
            enemy_2.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemy);
            enemy_3.transform.position  = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_4 = Instantiate(enemy);
            enemy_4.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14)); 
            GameObject enemy_5 = Instantiate(enemy);
            enemy_5.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14)); 
        }
        if (currentWave == 7f)
        {
            currentenemies = 5f;

            GameObject enemy_ = Instantiate(enemyred);
            enemy_.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14)); 
            GameObject enemy_2 = Instantiate(enemyred);
            enemy_2.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemy);
            enemy_3.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_4 = Instantiate(enemy);
            enemy_4.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_5 = Instantiate(enemy);
            enemy_5.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
        }
        if (currentWave == 8f)
        {
            currentenemies = 5f;

            GameObject enemy_ = Instantiate(enemyred);
            enemy_.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemyred);
            enemy_2.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemyred);
            enemy_3.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_4 = Instantiate(enemy);
            enemy_4.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_5 = Instantiate(enemy);
            enemy_5.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
        }
        if (currentWave >= 8f)
        {
            currentenemies = 5f;

            GameObject enemy_ = Instantiate(enemyred);
            enemy_.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_2 = Instantiate(enemyred);
            enemy_2.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_3 = Instantiate(enemyred);
            enemy_3.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_4 = Instantiate(enemy);
            enemy_4.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
            GameObject enemy_5 = Instantiate(enemy);
            enemy_5.transform.position = new Vector3(Random.Range(-22, 22), 8, Random.Range(-14, 14));
        }
    }
}
