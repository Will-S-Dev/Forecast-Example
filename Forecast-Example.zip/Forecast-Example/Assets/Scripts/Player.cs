﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

using EZCameraShake;
public class Player : MonoBehaviour
{
    public RigidbodyFirstPersonController rbfps;
    public Camera cam;
    private Rigidbody rb;

    public Animator PlayerAnim;

    public Animator CanvasAnim;

    public GameObject sword;
    public MeshCollider swordcol;
    public Rigidbody swordrb;


    public DetectObstruction detectObs;
    public AttackCollider AttackCollider;

    public float dragGround;
    public float dragAir;
    public float dragAttack;
    public float dragDash;

    public float Jumpspeed;

    public Transform PlayerGFX;
  
    public float DodgeSpeed;
    public float AttackSpeed;


    public bool IsHit;

    public bool IsAttack;

    public bool isDash;
    public bool isDashInvincible;

    public bool Dead;

    Vector2 input;
    Vector3 inputVector;


    private ForeCastManager fm;
    private Quaternion playerrot;
    private Quaternion camrot;
    public bool IsForecasting;
    private float recordedmag;
    private Vector3 recordedvel;

    private Spawner spawner;
    // Start is called before the first frame update
    void Start()
    {
        spawner = FindObjectOfType<Spawner>();
        rbfps = GetComponent<RigidbodyFirstPersonController>();
        rb = GetComponent<Rigidbody>();
        fm = FindObjectOfType<ForeCastManager>();
        AttackCollider.gameObject.SetActive(false);

    }

    void StopDash()
    {
        isDash = false;
    }
    void StopDashInvincible()
    {
        isDashInvincible = false;
    }
    void StopAttack()
    {
        IsAttack = false;
        AttackCollider.gameObject.SetActive(false);
    }

    public void EnemyHit()
    {
        CanvasAnim.Play("Slash");
        CameraShaker.Instance.ShakeOnce(5f, 20f, 0, 1f);
    }
    private void Update()
    {
        gameObject.layer = 11;
        if(fm.IsForecast)
        {
            gameObject.layer = 13;
        }
        if (isDashInvincible)
        {
            gameObject.layer = 13;
        }


        rb.drag = dragGround;

        if (!detectObs.Obstruction)
        {
            rb.drag = dragAir;
        }
        if(IsAttack)
        {
            rb.drag = dragAttack;
        }
        if(isDashInvincible)
        {
            rb.drag = dragDash;
        }

        if (!Dead)
        {
            if (Input.GetKeyDown(KeyCode.Space) && detectObs.Obstruction)
            {
                rb.AddForce(0, Jumpspeed, 0);
            }

            if (rb.velocity.sqrMagnitude > 0.5f && detectObs.Obstruction)
            {
                PlayerAnim.SetBool("IsWalk", true);
            }
            else
            {
                PlayerAnim.SetBool("IsWalk", false);
            }


            if (Input.GetButtonDown("Fire2") && !isDash)
            {
                CameraShaker.Instance.ShakeOnce(4f, 15f, 0, 0.5f);

                isDash = true;
                isDashInvincible = true;

                if (Input.GetAxisRaw("Vertical") > 0.3f && Input.GetAxisRaw("Horizontal") == 0f)
                {
                    rb.AddRelativeForce(0, 0, DodgeSpeed);
                }
                if (Input.GetAxisRaw("Vertical") < -0.3f && Input.GetAxisRaw("Horizontal") == 0f)
                {
                    rb.AddRelativeForce(0, 0, -DodgeSpeed);
                }
                if (Input.GetAxisRaw("Horizontal") > 0.3f && Input.GetAxisRaw("Vertical") == 0f)
                {
                    rb.AddRelativeForce(DodgeSpeed, 0, 0);
                }
                if (Input.GetAxisRaw("Horizontal") < -0.3f && Input.GetAxisRaw("Vertical") == 0f)
                {
                    rb.AddRelativeForce(-DodgeSpeed, 0, 0);
                }
                if (Input.GetAxisRaw("Vertical") > 0.3f)
                {
                    rb.AddRelativeForce(0, 0, DodgeSpeed / 1.5f);

                    if (Input.GetAxisRaw("Horizontal") > 0.3f)
                    {
                        rb.AddRelativeForce(DodgeSpeed / 1.5f, 0, 0);
                    }
                    if (Input.GetAxisRaw("Horizontal") < -0.3f)
                    {
                        rb.AddRelativeForce(-DodgeSpeed / 1.5f, 0, 0);
                    }
                }
                if (Input.GetAxisRaw("Vertical") < -0.3f)
                {
                    rb.AddRelativeForce(0, 0, -DodgeSpeed / 1.5f);

                    if (Input.GetAxisRaw("Horizontal") > 0.3f)
                    {
                        rb.AddRelativeForce(DodgeSpeed / 1.5f, 0, 0);
                    }
                    if (Input.GetAxisRaw("Horizontal") < -0.3f)
                    {
                        rb.AddRelativeForce(-DodgeSpeed / 1.5f, 0, 0);
                    }
                }


                Invoke("StopDashInvincible", 0.5f);

                Invoke("StopDash", 1f);
            }

            if (Input.GetButtonDown("Fire1") && !IsAttack)
            {
                AudioManager.instance.Play("Slash");
                IsAttack = true;
                PlayerAnim.Play("Attack");
                rb.velocity = cam.transform.forward * AttackSpeed;
                AttackCollider.gameObject.SetActive(true);
                Invoke("StopAttack", 0.5f);
            }





            if (Input.GetKeyDown(KeyCode.E) && !IsAttack && !isDash && spawner.currentenemies > 0f)
            {
                IsForecasting = true;
                fm.ForeCastStart_();
            }
            if (Input.GetKeyUp(KeyCode.E) && IsForecasting)
            {
                IsForecasting = false;
                fm.ForeCastEnd_();
            }


            if (fm.ForeCastStart)
            {
                AudioManager.instance.Play("Forecast");

                CameraShaker.Instance.ShakeOnce(4f, 10f, 0, 1f);

                rb.constraints = RigidbodyConstraints.FreezePosition;
                CanvasAnim.Play("ForeCastStart");
                camrot = cam.transform.rotation;
                playerrot = transform.rotation;

                recordedmag = rb.velocity.magnitude;
                recordedvel = rb.velocity.normalized;
            }
            if (fm.ForeCastEnd)
            {
                rb.constraints = RigidbodyConstraints.None;
                rb.constraints = RigidbodyConstraints.FreezeRotation;
                CanvasAnim.Play("ForeCastEnd");
                rb.velocity = recordedvel * recordedmag;
                rbfps.canrotate = false;
                cam.transform.rotation = camrot;
                transform.rotation = playerrot;
                InvokeNextFrame(CanRotate);
            }
        }


    }
    void CanRotate()
    {
        rbfps.canrotate = true;
    }
    public void Die()
    {
        PlayerAnim.enabled = false;
        rbfps.enabled = false;
        Dead = true;
        rb.constraints = RigidbodyConstraints.None;

        sword.transform.parent = null;
        swordrb.isKinematic = false;
        swordcol.enabled = true;

        swordrb.velocity = transform.forward * 1f + transform.up * 1f;

        fm.GameEnd();
    }
    public delegate void Function();

    public void InvokeNextFrame(Function function)
    {
        try
        {
            StartCoroutine(_InvokeNextFrame(function));
        }
        catch
        {
            Debug.Log("Trying to invoke " + function.ToString() + " but it doesnt seem to exist");
        }
    }

    IEnumerator _InvokeNextFrame(Function function)
    {
        yield return null;
        function();
    }
}

