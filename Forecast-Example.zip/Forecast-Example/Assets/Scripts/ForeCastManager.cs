﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ForeCastManager : MonoBehaviour
{
    public bool ForeCastStart;
    public bool ForeCastEnd;
    public bool IsForecast;

    public int Score;
    public Text scoreText;

    public Animator RestartText;
    public Text HighScore;

    public bool End;


    // Start is called before the first frame update
   public void AddScore()
    {
        Score++;
        scoreText.text = "Score : " + Score.ToString();
    }

    // Update is called once per frame
    void Start()
    {
        scoreText.text = "Score : " + Score.ToString();
    }
    public void ForeCastStart_()
    {
        IsForecast = true;
        InvokeNextFrame(ForeCastStart_2);
        ForeCastStart = true;
    }
    public void ForeCastEnd_()
    {
        IsForecast = false;

        InvokeNextFrame(ForeCastEnd_2);
        ForeCastEnd = true;

    }
    public void ForeCastStart_2()
    {
        ForeCastStart = false;
    }
    public void ForeCastEnd_2()
    {
        ForeCastEnd = false;
    }


    public void GameEnd()
    {
        End = true;
        RestartText.Play("Restart");
        if (Score > PlayerPrefs.GetInt("Score"))
        {
            PlayerPrefs.SetInt("Score", Score);
        }
        HighScore.text = "HighScore : " + PlayerPrefs.GetInt("Score").ToString();


    }


    private void Update()
    {
        if(End)
        {
           if( Input.GetKeyDown(KeyCode.Space))
            {
                SceneManager.LoadScene(1);
            }
        }
    }

    public delegate void Function();

    public void InvokeNextFrame(Function function)
    {
        try
        {
            StartCoroutine(_InvokeNextFrame(function));
        }
        catch
        {
            Debug.Log("Trying to invoke " + function.ToString() + " but it doesnt seem to exist");
        }
    }

    IEnumerator _InvokeNextFrame(Function function)
    {
        yield return null;
        function();
    }

}
