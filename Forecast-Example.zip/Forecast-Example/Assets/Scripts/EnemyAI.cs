﻿using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Transform Rotate;
    private Transform Player;
    public MeshRenderer meshrend;

    public GameObject ShurikenPrefab;
    public Transform ShurikenStartRotate;

    public Transform ShurikenStart;

    public ParticleSystem blacksmoke;


    public int AttackSeed;
    public float currentAttackAngleX;
    public float currentAttackAngleY;

    public float currentNumberOfShurikens;

    public int MoveSeed;
    public float currentMovement;


    private float AttackTimer;
    public float AttackTime;
    public float Appear;
    public float Throw;
    public float DissapearTime;



    private float MoveTimer;
    public float MoveTime;

    public float numberofShurikensThrown;
    public float MaxAngle;

    //record

    public Vector3 recordedpos;
    public Quaternion rotation;
    public float recordedAttackTimer;
    public int recordedAttackSeed;

    public float recordedMoveTimer;
    public int recordedMoveSeed;

    public Vector3 recordedVelocity;
    public float recordedMagnitude;

    public bool IsDissapear;



    public bool HasAttack;
    public bool HasThrowShuriken;
    public bool HasDissapear;
    public bool HasAttacktemp;
    public bool HasThrowShurikentemp;
    public bool HasDissapeartemp;

    public bool ParticleWasPlaying;
    public float particletimetemp;
    private Vector3 BlackSmokeInitalPos;


    private ForeCastManager fm;
    private Spawner spawner;

    public bool IsDead;
    private Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        fm = FindObjectOfType<ForeCastManager>();
        spawner = FindObjectOfType<Spawner>();

        BlackSmokeInitalPos = blacksmoke.transform.localPosition;
        rb = GetComponent<Rigidbody>();
         AttackSeed = Random.Range(0, 10000);
        MoveSeed = Random.Range(0, 10000);



        MoveTimer = MoveTime;
        Player = GameObject.FindGameObjectWithTag("Player").transform;
        Dissapear();
    }

    // Update is called once per frame
    void Update()
    {
        if (!IsDead)
        {
            if (transform.position.y < 0f)
            {
                transform.position = spawner.spawn1.position;
            }

                if (fm.ForeCastStart)
            {
                ParticleWasPlaying = blacksmoke.isPlaying;
                if (blacksmoke.isPlaying)
                {
                    particletimetemp = blacksmoke.time;
                }

                recordedpos = transform.position;
                rotation = Rotate.transform.rotation;
                recordedAttackTimer = AttackTimer;
                recordedAttackSeed = AttackSeed;

                recordedMoveTimer = MoveTimer;
                recordedMoveSeed = MoveSeed;

                recordedVelocity = rb.velocity.normalized;
                recordedMagnitude = rb.velocity.magnitude;
                IsDissapear = meshrend.enabled;

                HasAttacktemp = HasAttack;
                HasThrowShurikentemp = HasThrowShuriken;
            }
            if (fm.ForeCastEnd)
            {
                if (blacksmoke.isPlaying)
                {
                    blacksmoke.Clear();
                }
                if (ParticleWasPlaying)
                {
                    blacksmoke.transform.position = recordedpos;
                    blacksmoke.Simulate(particletimetemp);
                    blacksmoke.Play();
                }

                transform.position = recordedpos;
                Rotate.transform.rotation = rotation;
                AttackTimer = recordedAttackTimer;
                AttackSeed = recordedAttackSeed;
                MoveTimer = recordedMoveTimer;
                MoveSeed = recordedMoveSeed;

                rb.velocity = recordedVelocity * recordedMagnitude;
                meshrend.enabled = IsDissapear;

                HasAttack = HasAttacktemp;

                HasThrowShuriken = HasThrowShurikentemp;
            }

            Quaternion rot = Quaternion.LookRotation(Player.transform.position - transform.position);

            ShurikenStartRotate.transform.rotation = Quaternion.Lerp(ShurikenStart.transform.rotation, rot, Time.deltaTime * 10f);

            if (transform.position.y < 1.2f)
            {
                Quaternion newrot = Quaternion.Euler(0, rot.eulerAngles.y, 0);
                Rotate.rotation = Quaternion.Lerp(Rotate.rotation, newrot, Time.deltaTime * 10f);

            }
            else
            {
                Rotate.rotation = Quaternion.Lerp(Rotate.rotation, rot, Time.deltaTime * 10f);
            }


            AttackTimer -= Time.deltaTime;
            MoveTimer -= Time.deltaTime;
            if (AttackTimer < Appear && !HasAttack)
            {
                Attack();
                HasAttack = true;
            }
            if (AttackTimer < Throw && !HasThrowShuriken)
            {
                HasThrowShuriken = true;

                for (float i = 0; i < numberofShurikensThrown; i++)
                {
                    ThrowShuriken();

                }

            }
            if (AttackTimer < DissapearTime)
            {
                Dissapear();
            }
            if (MoveTimer < 0f)
            {
                Move();
            }
        }

    }

   public void Die()
    {
        fm.AddScore();
        IsDead = true;
        meshrend.enabled = true;
        rb.constraints = RigidbodyConstraints.None;
        Invoke("Gone", 2f);
        spawner.currentenemies--;


    }
    void Gone()
    {
        Destroy(gameObject);

    }
    void Attack()
    {
        blacksmoke.transform.localPosition = BlackSmokeInitalPos;
        blacksmoke.Play();

        meshrend.enabled = true;
    }
    void ThrowShuriken()
    {
        Random.InitState(AttackSeed);
        currentAttackAngleX = Random.Range(-MaxAngle, MaxAngle);
        Random.InitState(AttackSeed);
        currentAttackAngleY = Random.Range(-MaxAngle, MaxAngle);


        AttackSeed++;

        ShurikenStart.transform.localRotation = Quaternion.Euler(currentAttackAngleX, currentAttackAngleY, 0f);
        GameObject shurikenNew = Instantiate(ShurikenPrefab);
        shurikenNew.transform.rotation = ShurikenStart.rotation;
        shurikenNew.transform.position = ShurikenStart.position;
    }

    void Dissapear()
    {
        blacksmoke.transform.localPosition = BlackSmokeInitalPos;

        blacksmoke.Play();
        HasAttack = false;
        HasThrowShuriken = false;
        meshrend.enabled = false;
        AttackTimer = AttackTime;
        Random.InitState(AttackSeed);

        float i = Random.Range(0f, 3f);
        AttackTimer = AttackTime + i;
    }


    void Move()
    {
        MoveTimer = MoveTime;
        Random.InitState(MoveSeed);
        currentMovement = Random.Range(1, 13);

        MoveSeed++;

        if(currentMovement == 1)
        {
            rb.AddForce(Rotate.forward * 15f,ForceMode.Impulse);
        }
        if (currentMovement == 2)
        {
            rb.AddForce(Rotate.forward * -10f, ForceMode.Impulse);
        }
        if (currentMovement == 3)
        {
            rb.AddForce(Rotate.right * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 4)
        {
            rb.AddForce(Rotate.right * -15f, ForceMode.Impulse);

        }
        if (currentMovement == 5)
        {
            rb.AddForce(Rotate.forward * 5f + Rotate.up * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 6)
        {
            rb.AddForce(Rotate.forward * -10f + Rotate.up * 10f, ForceMode.Impulse);

        }
        if (currentMovement == 7)
        {
            rb.AddForce(Rotate.forward * 15f + Rotate.up * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 8)
        {
            rb.AddForce(Rotate.right * 15f + Rotate.up * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 9)
        {
            rb.AddForce(Rotate.right * -15f + Rotate.up * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 10)
        {
            rb.AddForce(Rotate.forward * 15f + Rotate.up * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 11)
        {
            rb.AddForce(Rotate.forward * 15f + Rotate.up * 15f, ForceMode.Impulse);

        }
        if (currentMovement == 12)
        {
            rb.AddForce(Rotate.forward * 15f, ForceMode.Impulse);
        }
        if (currentMovement == 13)
        {
            rb.AddForce(Rotate.forward * 15f, ForceMode.Impulse);
        }
    }
}
