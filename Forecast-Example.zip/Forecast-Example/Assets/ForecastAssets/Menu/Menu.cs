﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public Animator MenuAnim;
    public Text highscore;

    private void Start()
    {
        highscore.text = "HighScore : " + PlayerPrefs.GetInt("Score").ToString();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            MenuAnim.Play("Start");
            Invoke("Start_", 1f);
        }
    }
    void Start_()
    {

        SceneManager.LoadScene(1);
    }
}
